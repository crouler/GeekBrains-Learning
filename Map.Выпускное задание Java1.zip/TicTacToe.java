package Lesson_8;

public class TicTacToe {
    public static void main(String[] args) {
        new GameWindow();
    } // точка входа и ничего больше
}
